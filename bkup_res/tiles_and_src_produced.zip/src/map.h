#ifndef MAP_map_H
#define MAP_map_H
#define mapWidth 48
#define mapHeight 48
#include "MapInfo.h"
extern unsigned char bank_map;
extern struct MapInfo map;
#endif
