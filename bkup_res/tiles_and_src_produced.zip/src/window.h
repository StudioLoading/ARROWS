#ifndef MAP_window_H
#define MAP_window_H
#define windowWidth 20
#define windowHeight 4
#include "MapInfo.h"
extern unsigned char bank_window;
extern struct MapInfo window;
#endif
