#ifndef TILES_item_H
#define TILES_item_H
#include "TilesInfo.h"
extern unsigned char bank_item;
extern struct TilesInfo item;
#endif
