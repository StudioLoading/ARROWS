#ifndef TILES_archer_H
#define TILES_archer_H
#define archerCGBPal0c0 6076
#define archerCGBPal0c1 20318
#define archerCGBPal0c2 435
#define archerCGBPal0c3 32259

#define archerCGBPal1c0 6076
#define archerCGBPal1c1 20318
#define archerCGBPal1c2 435
#define archerCGBPal1c3 32259

#define archerCGBPal2c0 6076
#define archerCGBPal2c1 8935
#define archerCGBPal2c2 6596
#define archerCGBPal2c3 5344

#define archerCGBPal3c0 6076
#define archerCGBPal3c1 8935
#define archerCGBPal3c2 6596
#define archerCGBPal3c3 5344

#define archerCGBPal4c0 6076
#define archerCGBPal4c1 8935
#define archerCGBPal4c2 6596
#define archerCGBPal4c3 5344

#define archerCGBPal5c0 6076
#define archerCGBPal5c1 8935
#define archerCGBPal5c2 6596
#define archerCGBPal5c3 5344

#define archerCGBPal6c0 6076
#define archerCGBPal6c1 8935
#define archerCGBPal6c2 6596
#define archerCGBPal6c3 5344

#define archerCGBPal7c0 6076
#define archerCGBPal7c1 8935
#define archerCGBPal7c2 6596
#define archerCGBPal7c3 5344

#include "TilesInfo.h"
extern unsigned char bank_archer;
extern struct TilesInfo archer;
#endif
