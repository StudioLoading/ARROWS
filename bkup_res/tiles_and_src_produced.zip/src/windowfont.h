#ifndef TILES_windowfont_H
#define TILES_windowfont_H
#include "TilesInfo.h"
extern unsigned char bank_windowfont;
extern struct TilesInfo windowfont;
#endif
