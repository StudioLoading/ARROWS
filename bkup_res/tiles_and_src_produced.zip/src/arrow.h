#ifndef TILES_arrow_H
#define TILES_arrow_H
#include "TilesInfo.h"
extern unsigned char bank_arrow;
extern struct TilesInfo arrow;
#endif
