#ifndef TILES_platform_H
#define TILES_platform_H
#include "TilesInfo.h"
extern unsigned char bank_platform;
extern struct TilesInfo platform;
#endif
