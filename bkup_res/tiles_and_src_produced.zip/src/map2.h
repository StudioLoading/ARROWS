#ifndef MAP_map2_H
#define MAP_map2_H
#define map2Width 48
#define map2Height 48
#include "MapInfo.h"
extern unsigned char bank_map2;
extern struct MapInfo map2;
#endif
