#ifndef MAP_mapgameover_H
#define MAP_mapgameover_H
#define mapgameoverWidth 20
#define mapgameoverHeight 16
#include "MapInfo.h"
extern unsigned char bank_mapgameover;
extern struct MapInfo mapgameover;
#endif
