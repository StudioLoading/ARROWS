#ifndef TILES_enemy_H
#define TILES_enemy_H
#include "TilesInfo.h"
extern unsigned char bank_enemy;
extern struct TilesInfo enemy;
#endif
